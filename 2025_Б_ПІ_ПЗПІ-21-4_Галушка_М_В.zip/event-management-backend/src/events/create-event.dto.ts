import { Type } from 'class-transformer';
import { IsNotEmpty, IsOptional, IsString, IsDateString, IsNumber, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateEventDto {
  @ApiProperty({ example: 'Мій івент' })
  @IsNotEmpty()
  @IsString()
  title: string;

  @ApiProperty({ example: 'Опис івенту', required: false })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ example: '2025-05-01T10:00:00Z' })
  @IsDateString()
  start_date: string;

  @ApiProperty({ example: '2025-05-01T12:00:00Z' })
  @IsDateString()
  end_date: string;

  @ApiProperty({ example: 'Київ', required: false })
  @IsOptional()
  @IsString()
  location?: string;

  @ApiProperty({ example: 'Вулиця Пушкіна, 10', required: false })
  @IsOptional()
  @IsString()
  street?: string;

  @ApiProperty({ example: 150, required: false })
  @IsOptional()
@Type(() => Number)
@IsNumber()
@Min(0)
price?: number;

  
  @IsOptional()
  @IsString()
  photo?: string;
}
