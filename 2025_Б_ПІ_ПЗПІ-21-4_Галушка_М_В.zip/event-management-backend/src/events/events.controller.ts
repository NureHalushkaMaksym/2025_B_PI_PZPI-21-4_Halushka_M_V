import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  UseInterceptors,
  UploadedFile,
  NotFoundException,
  UsePipes,
  ValidationPipe,
  BadRequestException,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiConsumes,
  ApiParam,
} from '@nestjs/swagger';
import { EventsService } from './events.service';
import { Event } from './events.entity';
import { CreateEventDto } from './create-event.dto';
import { UpdateEventDto } from './update-event.dto';

@ApiTags('events')
@Controller('events')
export class EventsController {
  constructor(private readonly eventsService: EventsService) {}

  @Get()
  @ApiOperation({ summary: 'Отримати список всіх подій' })
  @ApiResponse({ status: 200, description: 'Список подій', type: [Event] })
  findAll(): Promise<Event[]> {
    return this.eventsService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Отримати подію за ID' })
  @ApiParam({ name: 'id', type: Number, description: 'ID події' })
  @ApiResponse({ status: 200, description: 'Подія знайдена', type: Event })
  @ApiResponse({ status: 404, description: 'Подія не знайдена' })
  async findOne(@Param('id') id: string): Promise<Event> {
    const event = await this.eventsService.findOne(+id);
    if (!event) {
      throw new NotFoundException(`Подія з id=${id} не знайдена`);
    }
    return event;
  }

  @Post()
  @UseInterceptors(FileInterceptor('photo', {
    storage: diskStorage({
      destination: './uploads',
      filename: (req, file, cb) => {
        const uniqueName = Date.now() + '-' + file.originalname.replace(/\s/g, '_');
        cb(null, uniqueName);
      },
    }),
    fileFilter: (req, file, cb) => {
      if (!file.mimetype.match(/\/(jpg|jpeg|png|gif|webp)$/)) {
        return cb(new Error('Only image files are allowed!'), false);
      }
      cb(null, true);
    },
    limits: { fileSize: 5 * 1024 * 1024 },
  }))
  @ApiConsumes('multipart/form-data')
  @ApiOperation({ summary: 'Створити нову подію' })
  @ApiResponse({ status: 201, description: 'Подія створена', type: Event })
  @UsePipes(new ValidationPipe({ whitelist: true, transform: true }))
  async create(
    @UploadedFile() file: Express.Multer.File,
    @Body() body: CreateEventDto,
  ): Promise<Event> {
    if ('id' in body || 'photoUri' in body) {
      throw new BadRequestException('Неприпустимі поля: id або photoUri');
    }

    const event: Partial<Event> = {
      title: body.title,
      description: body.description,
      start_date: new Date(body.start_date),
      end_date: new Date(body.end_date),
      location: body.location,
      street: body.street,
      price: body.price,
      photoUrl: file ? `/uploads/${file.filename}` : undefined,
    };

    return this.eventsService.create(event);
  }

  @Put(':id')
  @UseInterceptors(FileInterceptor('photo', {
    storage: diskStorage({
      destination: './uploads',
      filename: (req, file, cb) => {
        const uniqueName = Date.now() + '-' + file.originalname.replace(/\s/g, '_');
        cb(null, uniqueName);
      },
    }),
    fileFilter: (req, file, cb) => {
      if (!file.mimetype.match(/\/(jpg|jpeg|png|gif|webp)$/)) {
        return cb(new Error('Only image files are allowed!'), false);
      }
      cb(null, true);
    },
    limits: { fileSize: 5 * 1024 * 1024 },
  }))
  @ApiConsumes('multipart/form-data')
  @ApiOperation({ summary: 'Оновити подію за ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Подія оновлена', type: Event })
  @UsePipes(new ValidationPipe({ whitelist: true, transform: true }))
  async update(
    @Param('id') id: string,
    @UploadedFile() file: Express.Multer.File,
    @Body() body: UpdateEventDto,
  ): Promise<Event> {
    const updateData: Partial<Event> = {
      title: body.title,
      description: body.description,
      start_date: body.start_date ? new Date(body.start_date) : undefined,
      end_date: body.end_date ? new Date(body.end_date) : undefined,
      location: body.location,
      street: body.street,
      price: body.price,
    };

    if (file) {
      updateData.photoUrl = `/uploads/${file.filename}`;
    }

    const updated = await this.eventsService.update(+id, updateData);
    if (!updated) {
      throw new NotFoundException(`Подія з id=${id} не знайдена`);
    }
    return updated;
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Видалити подію за ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiResponse({ status: 200, description: 'Подія видалена' })
  @ApiResponse({ status: 404, description: 'Подія не знайдена' })
  async remove(@Param('id') id: string): Promise<{ message: string }> {
    const deleted = await this.eventsService.remove(+id);
    if (!deleted) {
      throw new NotFoundException(`Подія з id=${id} не знайдена`);
    }
    return { message: 'Подію успішно видалено' };
  }
}
