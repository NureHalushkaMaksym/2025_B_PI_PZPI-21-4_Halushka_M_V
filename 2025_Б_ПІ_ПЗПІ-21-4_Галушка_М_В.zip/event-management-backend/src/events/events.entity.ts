import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { User } from '../user/user.entity';
import { Ticket } from '../ticket/ticket.entity';

@Entity('events')
export class Event {

  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 255 })
  title: string;

  @Column('text', { nullable: true })
  description: string;

  @Column('timestamp')
  start_date: Date;

  @Column('timestamp')
  end_date: Date;

  @Column({ length: 255, nullable: true })
  location: string;

  @Column({ length: 255, nullable: true })
  street: string;

  @Column('decimal', { nullable: true })   
  price: number;

  @ManyToOne(() => User, (user) => user.events)
  @JoinColumn({ name: 'created_by' })
  createdBy: User;

  

  @Column({ name: 'photo_url', type: 'text', nullable: true })
photoUrl: string;
}
