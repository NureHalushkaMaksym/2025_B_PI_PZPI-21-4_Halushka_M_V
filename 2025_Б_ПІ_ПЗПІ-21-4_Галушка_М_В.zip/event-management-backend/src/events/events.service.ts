import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Event } from './events.entity';
import { NotFoundException } from '@nestjs/common';


@Injectable()
export class EventsService {
  constructor(
    @InjectRepository(Event)
    private eventsRepository: Repository<Event>,
  ) {}

  async findAll(): Promise<Event[]> {
    return this.eventsRepository.find();
  }

  async create(eventData: Partial<Event>): Promise<Event> {
    const event = this.eventsRepository.create(eventData);
    return this.eventsRepository.save(event);
  }

  async update(id: number, updateData: Partial<Event>): Promise<Event | null> {
  const event = await this.eventsRepository.findOne({ where: { id } });
if (!event) {
  throw new NotFoundException(`Подія з id=${id} не знайдена`);
}
const updatedEvent = this.eventsRepository.merge(event, updateData);
return await this.eventsRepository.save(updatedEvent);


}


  async remove(id: number): Promise<boolean> {
  const result = await this.eventsRepository.delete(id);
  return result.affected !== 0;
}

  async findOne(id: number): Promise<Event | null> {
    return this.eventsRepository.findOne({ where: { id } });
  }
}
