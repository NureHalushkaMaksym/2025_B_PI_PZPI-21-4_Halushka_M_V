import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsersService } from './user.service';
import { UsersController } from './user.controller';
import { User } from './user.entity';

@Module({
  imports: [TypeOrmModule.forFeature([User])], // Імпортуємо репозиторій User для доступу в сервісі
  providers: [UsersService], // Підключаємо UsersService
  controllers: [UsersController], // Підключаємо UsersController
  exports: [UsersService],
})
export class UsersModule {}
