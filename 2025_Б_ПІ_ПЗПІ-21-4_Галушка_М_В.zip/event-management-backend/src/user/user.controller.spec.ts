import { Test, TestingModule } from '@nestjs/testing';
import { UsersController } from './user.controller';  // Заміни UserController на UsersController
import { UsersService } from './user.service'; // Заміни UserService на UsersService

describe('UsersController', () => {
  let controller: UsersController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [UsersController],  // Заміни UserController на UsersController
      providers: [UsersService],  // Заміни UserService на UsersService
    }).compile();

    controller = module.get<UsersController>(UsersController);  // Заміни UserController на UsersController
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
