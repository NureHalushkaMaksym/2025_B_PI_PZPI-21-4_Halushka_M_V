import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateReviewDto } from './dto/create-review.dto';
import { Review } from './review.entity';

@Injectable()
export class ReviewService {
  constructor(
    @InjectRepository(Review)
    private readonly reviewRepository: Repository<Review>,
  ) {}

  async create(createReviewDto: CreateReviewDto, user: any): Promise<Review> {
    const review = this.reviewRepository.create({
      ...createReviewDto,
      user_id: user.id,
    });
    return this.reviewRepository.save(review);
  }

  findAll() {
    return this.reviewRepository.find();
  }

  findOne(id: number) {
    return this.reviewRepository.findOneBy({ id });
  }

  async remove(id: number) {
    await this.reviewRepository.delete(id);
    return { message: 'Review deleted' };
  }
}
