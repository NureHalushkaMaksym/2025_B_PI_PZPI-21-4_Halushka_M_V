import { IsInt, IsString, IsNotEmpty, Min, Max } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateReviewDto {
  @ApiProperty({ example: 1, description: 'ID івенту, до якого залишають відгук' })
  @IsInt()
  event_id: number;

  @ApiProperty({ example: 5, description: 'Оцінка (від 1 до 5)' })
  @IsInt()
  @Min(1)
  @Max(5)
  rating: number;

  @ApiProperty({ example: 'Чудовий захід!', description: 'Коментар до івенту' })
  @IsString()
  @IsNotEmpty()
  comment: string;
}
