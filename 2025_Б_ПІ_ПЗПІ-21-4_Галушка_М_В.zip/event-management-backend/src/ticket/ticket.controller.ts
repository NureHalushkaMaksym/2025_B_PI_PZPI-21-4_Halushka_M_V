import { Body, Controller, Post, Get, Param, ParseIntPipe, Patch } from '@nestjs/common';
import { TicketService } from './ticket.service';
import { CreateTicketDto } from './dto/create-ticket.dto';
import { ApiTags, ApiBody } from '@nestjs/swagger';

@ApiTags('tickets')
@Controller('tickets')
export class TicketController {
  constructor(private readonly ticketService: TicketService) {}

  @Post()
  @ApiBody({ type: CreateTicketDto })
  create(@Body() createTicketDto: CreateTicketDto) {
    return this.ticketService.create(createTicketDto);
  }

  // Новий endpoint для підтвердження купівлі квитка
  @Patch('confirm/:ticketId')
  confirmTicket(@Param('ticketId', ParseIntPipe) ticketId: number) {
    return this.ticketService.confirmTicketPurchase(ticketId);
  }

  // Endpoint для статистики по події
  @Get('statistics/:eventId')
  getStatistics(@Param('eventId', ParseIntPipe) eventId: number) {
    return this.ticketService.getStatistics(eventId);
  }
}
