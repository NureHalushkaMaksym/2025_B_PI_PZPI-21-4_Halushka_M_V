import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Ticket } from './ticket.entity';
import { TicketService } from './ticket.service';
import { TicketController } from './ticket.controller';
import { Event } from '../events/events.entity'; // Виправлений шлях

@Module({
  imports: [TypeOrmModule.forFeature([Ticket, Event])], // правильні імпорти
  providers: [TicketService],
  controllers: [TicketController],
  exports: [TicketService], // Якщо потрібно використовувати цей сервіс в інших модулях
})
export class TicketModule {}
