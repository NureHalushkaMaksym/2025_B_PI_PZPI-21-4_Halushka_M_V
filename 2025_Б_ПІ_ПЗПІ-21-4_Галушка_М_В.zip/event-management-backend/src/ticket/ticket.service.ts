import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Ticket, TicketStatus } from './ticket.entity';
import { Repository } from 'typeorm';
import { CreateTicketDto } from './dto/create-ticket.dto';
import { Event } from '../events/events.entity';

@Injectable()
export class TicketService {
  constructor(
    @InjectRepository(Ticket)
    private readonly ticketRepository: Repository<Ticket>,

    @InjectRepository(Event)
    private readonly eventRepository: Repository<Event>,
  ) {}

  async create(dto: CreateTicketDto) {
    const event = await this.eventRepository.findOne({ where: { id: dto.event_id } });
    if (!event) {
      throw new NotFoundException(`Event with ID ${dto.event_id} not found`);
    }

    // Створюємо квиток зі статусом PENDING за замовчуванням
    const ticket = this.ticketRepository.create({
      ...dto,
      status: TicketStatus.PENDING,
    });
    return this.ticketRepository.save(ticket);
  }

  // Метод підтвердження оплати/купівлі квитка
  async confirmTicketPurchase(ticketId: number) {
    const ticket = await this.ticketRepository.findOne({ where: { id: ticketId } });
    if (!ticket) {
      throw new NotFoundException(`Ticket with ID ${ticketId} not found`);
    }

    if (ticket.status === TicketStatus.CONFIRMED) {
      throw new BadRequestException('Ticket is already confirmed');
    }

    ticket.status = TicketStatus.CONFIRMED;
    return this.ticketRepository.save(ticket);
  }

  // Отримання статистики по події
  async getStatistics(eventId: number) {
    const event = await this.eventRepository.findOne({ where: { id: eventId } });
    if (!event) {
      throw new NotFoundException(`Event with ID ${eventId} not found`);
    }

    const confirmedTicketsCount = await this.ticketRepository.count({
      where: {
        event_id: eventId,
        status: TicketStatus.CONFIRMED,
      },
    });

    const totalAmount = confirmedTicketsCount * (event.price ?? 0);

    return {
      totalTickets: confirmedTicketsCount,
      totalAmount,
    };
  }
}
