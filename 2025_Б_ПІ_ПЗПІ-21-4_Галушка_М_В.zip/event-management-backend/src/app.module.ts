import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsersModule } from './user/user.module';  // Імпорт UsersModule
import { EventsModule } from './events/events.module';
import { TicketModule } from './ticket/ticket.module';
import { ReviewModule } from './review/review.module';
import { AuthModule } from './auth/auth.module';
import { NotificationModule } from './notification/notification.module';
import { UploadController } from './upload/upload.controller';

@Module({
  controllers: [UploadController], 
})


@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'postgres',
      password: 'halushka1',
      database: 'event_management',
      autoLoadEntities: true,
      synchronize: true,
    }),
    UsersModule, 
    EventsModule,
    TicketModule,
    ReviewModule,
    NotificationModule,
    AuthModule,
  ],
})
export class AppModule {}
