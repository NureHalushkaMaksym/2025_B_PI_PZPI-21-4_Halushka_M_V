import { Module } from '@nestjs/common';
import { AuthController } from './auth.controller';
import { UsersModule } from '../user/user.module';

@Module({
  imports: [UsersModule], // для доступу до UsersService
  controllers: [AuthController],
})
export class AuthModule {}
