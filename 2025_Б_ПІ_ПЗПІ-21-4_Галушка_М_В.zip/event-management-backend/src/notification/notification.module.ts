import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Notification } from './notification.entity';
import { NotificationService } from './notification.service';
import { NotificationController } from './notification.controller';

@Module({
  imports: [TypeOrmModule.forFeature([Notification])],  // Ось ця стрічка дуже важлива
  providers: [NotificationService],
  controllers: [NotificationController],
  exports: [NotificationService], // Якщо плануєш використовувати NotificationService в інших модулях
})
export class NotificationModule {}
