import { IsInt, IsNotEmpty, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateNotificationDto {
  @ApiProperty({ example: 1, description: 'ID користувача' })
  @IsInt()
  user_id: number;

  @ApiProperty({ example: 'Ваша заявка прийнята', description: 'Текст повідомлення' })
  @IsString()
  @IsNotEmpty()
  message: string;
}
