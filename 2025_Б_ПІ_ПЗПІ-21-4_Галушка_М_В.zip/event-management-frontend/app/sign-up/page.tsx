"use client";

import React, { useState } from "react";
import { Container, TextField, Button, Typography, Box } from "@mui/material";
import { useRouter } from "next/navigation";
import { useSnackbar } from "notistack";

export default function SignUpPage() {
  const [form, setForm] = useState({
    first_name: "",
    last_name: "",
    email: "",
    password: "",
  });
  const router = useRouter();
  const { enqueueSnackbar } = useSnackbar();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const res = await fetch("http://localhost:3000/api/users/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      if (!res.ok) {
        const data = await res.json();
        enqueueSnackbar(data.message || "Registration failed", { variant: "error" });
        return;
      }

      enqueueSnackbar("Successfully registered!", { variant: "success" });

      // Переадресація на сторінку /event
      router.push("/event");
    } catch (err) {
      enqueueSnackbar("Network error", { variant: "error" });
    }
  };

  return (
    <Container maxWidth="sm" sx={{ mt: 6 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Register
      </Typography>

      <Box component="form" onSubmit={handleSubmit} noValidate>
        <TextField
          fullWidth
          label="First Name"
          name="first_name"
          value={form.first_name}
          onChange={handleChange}
          margin="normal"
          required
          variant="outlined"
          sx={{ borderRadius: 3 }}
        />
        <TextField
          fullWidth
          label="Last Name"
          name="last_name"
          value={form.last_name}
          onChange={handleChange}
          margin="normal"
          required
          variant="outlined"
          sx={{ borderRadius: 3 }}
        />
        <TextField
          fullWidth
          label="Email"
          name="email"
          type="email"
          value={form.email}
          onChange={handleChange}
          margin="normal"
          required
          variant="outlined"
          sx={{ borderRadius: 3 }}
        />
        <TextField
          fullWidth
          label="Password"
          name="password"
          type="password"
          value={form.password}
          onChange={handleChange}
          margin="normal"
          required
          inputProps={{ minLength: 6 }}
          variant="outlined"
          sx={{ borderRadius: 3 }}
        />

        <Button
          type="submit"
          variant="contained"
          fullWidth
          sx={{
            mt: 3,
            borderRadius: 3,
            backgroundColor: "white",
            color: "black",
            fontWeight: "bold",
            '&:hover': {
              backgroundColor: "#f0f0f0",
            }
          }}
        >
          Sign Up
        </Button>
      </Box>
    </Container>
  );
}
