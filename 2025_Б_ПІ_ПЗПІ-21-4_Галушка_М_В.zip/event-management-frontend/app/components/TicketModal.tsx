import React from "react";
import { Box, Button, Typography, Modal } from "@mui/material";
import jsPDF from "jspdf";

interface TicketModalProps {
  open: boolean;
  onClose: () => void;
  event: {
    title: string;
    location?: string;
    start_date: string;
    price?: number;
  } | null;
  userInfo: {
    firstName: string;
    lastName: string;
    email: string;
  };
}

const style = {
  position: "absolute" as const,
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  borderRadius: 2,
  boxShadow: 24,
  p: 4,
  textAlign: "center",
};

export const TicketModal: React.FC<TicketModalProps> = ({
  open,
  onClose,
  event,
  userInfo,
}) => {
  const handleDownloadPdf = () => {
    if (!event) return;

    const doc = new jsPDF();

    doc.setFontSize(20);
    doc.text("Квиток на подію", 105, 20, { align: "center" });

    doc.setFontSize(14);
    doc.text(`Подія: ${event.title}`, 20, 40);
    doc.text(`Місце: ${event.location || "Не вказано"}`, 20, 50);
    doc.text(`Дата: ${new Date(event.start_date).toLocaleString()}`, 20, 60);
    doc.text(`Ціна: ${event.price !== undefined ? `${event.price} ₴` : "Безкоштовно"}`, 20, 70);
    doc.text(`Ім'я: ${userInfo.firstName} ${userInfo.lastName}`, 20, 80);
    doc.text(`Email: ${userInfo.email}`, 20, 90);
    doc.text(`Дата покупки: ${new Date().toLocaleDateString()}`, 20, 100);

    doc.save(`квиток_${event.title.replace(/\s+/g, '_')}.pdf`);
  };

  return (
    <Modal open={open} onClose={onClose}>
      <Box sx={style}>
        <Typography variant="h6" gutterBottom>
          Ваш квиток
        </Typography>

        {event ? (
          <>
            <Typography sx={{ mb: 2 }}>
              <b>Подія:</b> {event.title}
            </Typography>
            <Typography sx={{ mb: 2 }}>
              <b>Місце:</b> {event.location || "Не вказано"}
            </Typography>
            <Typography sx={{ mb: 2 }}>
              <b>Дата:</b> {new Date(event.start_date).toLocaleString()}
            </Typography>
            <Typography sx={{ mb: 2 }}>
              <b>Ціна:</b> {event.price !== undefined ? `${event.price} ₴` : "Безкоштовно"}
            </Typography>
            <Typography sx={{ mb: 2 }}>
              <b>Ім'я:</b> {userInfo.firstName} {userInfo.lastName}
            </Typography>
            <Typography sx={{ mb: 3 }}>
              <b>Email:</b> {userInfo.email}
            </Typography>

            <Button variant="contained" onClick={handleDownloadPdf} sx={{ mr: 2 }}>
              Завантажити PDF
            </Button>
            <Button variant="outlined" onClick={onClose}>
              Закрити
            </Button>
          </>
        ) : (
          <Typography>Інформація про подію відсутня</Typography>
        )}
      </Box>
    </Modal>
  );
};