"use client";

import React from "react";

type Props = {
  event: {
    title: string;
    description?: string;
    start_date: string;
    end_date: string;
    location?: string;
    street?: string;
    photoUrl?: string;
  };
};

export function EventDetails({ event }: Props) {
  return (
    <div style={{ maxWidth: 800, margin: "0 auto" }}>
      <h1>{event.title}</h1>

      {event.photoUrl && (
        <img
          src={event.photoUrl}
          alt={event.title}
          style={{
            width: "100%",
            maxHeight: "400px",
            objectFit: "cover",
            borderRadius: "12px",
            marginBottom: "1rem",
          }}
        />
      )}

      <p><strong>📝 Опис:</strong> {event.description || "Немає опису"}</p>

      <p>
        <strong>📍 Локація:</strong> {event.location} {event.street && `, ${event.street}`}
      </p>

      <p>
        <strong>🕒 Час:</strong> {new Date(event.start_date).toLocaleString()} —{" "}
        {new Date(event.end_date).toLocaleString()}
      </p>
    </div>
  );
}

export default EventDetails;