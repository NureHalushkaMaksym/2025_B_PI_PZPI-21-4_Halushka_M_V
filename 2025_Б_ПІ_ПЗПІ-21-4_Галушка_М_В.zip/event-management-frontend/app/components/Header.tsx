"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  AppBar,
  Toolbar,
  IconButton,
  InputBase,
  Box,
  Button,
  Avatar,
  Menu,
  MenuItem,
  Badge,
  Typography,
} from "@mui/material";
import HomeIcon from "@mui/icons-material/Home";
import NotificationsIcon from "@mui/icons-material/Notifications";
import { useState } from "react";

export default function Header() {
  const pathname = usePathname();
  const isHomePage = pathname === "/";

  const [isLoggedIn, setIsLoggedIn] = useState(true);

  // Меню профілю
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  // Меню сповіщень
  const [notifAnchorEl, setNotifAnchorEl] = useState<null | HTMLElement>(null);
  const notifOpen = Boolean(notifAnchorEl);
  const handleNotifOpen = (event: React.MouseEvent<HTMLElement>) => {
    setNotifAnchorEl(event.currentTarget);
  };
  const handleNotifClose = () => {
    setNotifAnchorEl(null);
  };

  // Порожній масив сповіщень
  const notifications: string[] = [];

  return (
    <AppBar position="static" sx={{ bgcolor: "#1976d2" }}>
      <Toolbar sx={{ display: "flex", justifyContent: "space-between", gap: 2 }}>
        {/* Домік зліва */}
        <Link href="/" passHref legacyBehavior>
          <IconButton sx={{ color: "white" }} edge="start" aria-label="home" component="a">
            <HomeIcon />
          </IconButton>
        </Link>

        {/* Пошукове поле по центру */}
        <Box sx={{ flexGrow: 1, display: "flex", justifyContent: "center" }}>
          <InputBase
            placeholder="Search..."
            sx={{
              backgroundColor: "white",
              color: "black",
              px: 2,
              py: 0.5,
              borderRadius: 4,
              width: "100%",
              maxWidth: 400,
            }}
            inputProps={{ "aria-label": "search" }}
          />
        </Box>

        {/* Сповіщення та профіль */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          {isLoggedIn && (
            <>
              {/* Значок сповіщень */}
              <IconButton
                onClick={handleNotifOpen}
                sx={{ color: "white" }}
                aria-controls={notifOpen ? "notification-menu" : undefined}
                aria-haspopup="true"
                aria-expanded={notifOpen ? "true" : undefined}
                aria-label="notifications"
              >
                <Badge badgeContent={notifications.length} color="error">
                  <NotificationsIcon />
                </Badge>
              </IconButton>
              <Menu
                id="notification-menu"
                anchorEl={notifAnchorEl}
                open={notifOpen}
                onClose={handleNotifClose}
                anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                transformOrigin={{ vertical: "top", horizontal: "right" }}
                disableScrollLock
              >
                {notifications.length === 0 ? (
                  <MenuItem disabled>Немає сповіщень</MenuItem>
                ) : (
                  notifications.map((notif, index) => (
                    <MenuItem key={index} onClick={handleNotifClose}>
                      <Typography variant="body2">{notif}</Typography>
                    </MenuItem>
                  ))
                )}
              </Menu>
            </>
          )}

          {!isLoggedIn ? (
            <>
              <Button component={Link} href="/sign-in" sx={{ color: "white" }}>
                Sign In
              </Button>
              <Button component={Link} href="/sign-up" sx={{ color: "white" }}>
                Sign Up
              </Button>
            </>
          ) : (
            <>
              <IconButton
                onClick={handleMenuOpen}
                sx={{ p: 0 }}
                aria-controls={open ? "profile-menu" : undefined}
                aria-haspopup="true"
                aria-expanded={open ? "true" : undefined}
                aria-label="account of current user"
              >
                <Avatar alt="User Profile" src="/path_to_avatar.jpg" />
              </IconButton>
              <Menu
                id="profile-menu"
                anchorEl={anchorEl}
                open={open}
                onClose={handleMenuClose}
                anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                transformOrigin={{ vertical: "top", horizontal: "right" }}
                disableScrollLock
              >
                <MenuItem onClick={handleMenuClose} component={Link} href="/profile">
                </MenuItem>
                <MenuItem
                  onClick={() => {
                    handleMenuClose();
                    setIsLoggedIn(false);
                  }}
                >
                  Logout
                </MenuItem>
              </Menu>
            </>
          )}
        </Box>
      </Toolbar>
    </AppBar>
  );
}
