"use client";

import { Box, Typography } from '@mui/material';

export default function HomePage() {
  return (
    <Box
      sx={{
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        px: 2,
      }}
    >
      <Typography variant="h3" gutterBottom>
        Welcome to Event Management System
      </Typography>
      <Typography variant="h5">
        Please sign in or register to access all features
      </Typography>
    </Box>
  );
}
