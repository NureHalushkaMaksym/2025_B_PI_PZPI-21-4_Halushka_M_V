export async function uploadPhoto(photo: File): Promise<string | null> {
  const formData = new FormData();
  formData.append('photo', photo);

  const res = await fetch('http://localhost:3000/upload', {
    method: 'POST',
    body: formData,
  });

  const data = await res.json();

  return data?.filename || null;
}
