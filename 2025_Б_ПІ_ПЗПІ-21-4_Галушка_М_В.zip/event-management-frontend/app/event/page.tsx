"use client";

import React, { useState, useEffect } from "react";
import {
  Avatar,
  Box,
  Button,
  Chip,
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  Paper,
  Snackbar,
  Stack,
  TextField,
  Typography,
  Alert,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Rating,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { useAuth } from "../contexts/AuthContext";
import jsPDF from "jspdf";
import { useRouter } from "next/navigation";
import { TicketModal } from "../components/TicketModal";



type User = {
  id: string;
  name: string;
  email: string;
  avatar?: string;
};

type Review = {
  id: string;
  user: User;
  createdAt: string;
  rating: number;
  text: string;
};

type Event = {
  id: string;
  title: string;
  description?: string;
  start_date: string;
  end_date: string;
  location?: string;
  street?: string;
  price?: number;
  photo?: string;
  reviews?: Review[];
  createdBy?: string;
};

export default function EventsComponent() {
  const router = useRouter();
  const { user } = useAuth();
  const [events, setEvents] = useState<Event[]>([]);
  const [filteredEvents, setFilteredEvents] = useState<Event[]>([]);
  const [searchTitle, setSearchTitle] = useState("");
  const [searchLocation, setSearchLocation] = useState("");
  const [maxPrice, setMaxPrice] = useState<number | "">("");
  const [startDate, setStartDate] = useState("");

  const [openAddDialog, setOpenAddDialog] = useState(false);
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);

 
  const [newEvent, setNewEvent] = useState<Partial<Event>>({});
  const [editingEvent, setEditingEvent] = useState<Partial<Event> | null>(null);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [editPhotoFile, setEditPhotoFile] = useState<File | null>(null);
  const [newReview, setNewReview] = useState({
    text: "",
    rating: 5,
  });

  const [ticketPDF, setTicketPDF] = useState<Blob | null>(null);
  const generateTicketPDF = () => {
  const doc = new jsPDF();
  doc.setFontSize(18);
  doc.text("Квиток на подію", 20, 20);
  doc.setFontSize(12);
  doc.text(`Назва події: ${selectedEvent?.title}`, 20, 40);
  doc.text(`Місце: ${selectedEvent?.location || "Невідомо"}`, 20, 50);
  doc.text(`Дата: ${new Date(selectedEvent?.start_date || "").toLocaleString()}`, 20, 60);
  doc.text(`Ім'я: ${firstName} ${lastName}`, 20, 70);
  const pdfBlob = doc.output("blob");
  setTicketPDF(pdfBlob);
};


  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCVV, setCardCVV] = useState("");
  const [paymentError, setPaymentError] = useState("");

  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState<
    "success" | "error" | "info" | "warning"
  >("success");

  const cities = ["Київ", "Полтава", "Львів"];

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const res = await fetch("http://localhost:3000/api/events");
        if (!res.ok) throw new Error("Failed to fetch events");
        const data = await res.json();
        setEvents(data);
        setFilteredEvents(data);
      } catch (error) {
        showSnackbar("Помилка завантаження подій", "error");
      }
    };
    fetchEvents();
  }, []);

  const uploadPhoto = async (file: File): Promise<string> => {
  const formData = new FormData();
  formData.append('file', file);

  const res = await fetch('http://localhost:3000/upload', {
    method: 'POST',
    body: formData,
  });

  if (!res.ok) {
    throw new Error('Upload failed');
  }

  const data = await res.json();
  return data.url; 
};

const handleCreateOrUpdateEvent = async (eventData: Partial<Event>, file?: File) => {
  let photoUrl = eventData.photo;

  if (file) {
    photoUrl = await uploadPhoto(file); 
  }

  const res = await fetch(`http://localhost:3000/api/events`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${localStorage.getItem('token')}`,
    },
    body: JSON.stringify({
      ...eventData,
      photo: photoUrl, 
    }),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(JSON.stringify(err));
  }
};


  useEffect(() => {
    let filtered = [...events];

    if (searchTitle.trim()) {
      filtered = filtered.filter((e) =>
        e.title.toLowerCase().includes(searchTitle.toLowerCase())
      );
    }

    if (searchLocation) {
      filtered = filtered.filter(
        (e) => e.location?.toLowerCase() === searchLocation.toLowerCase()
      );
    }

    if (maxPrice !== "") {
      filtered = filtered.filter((e) => (e.price ?? 0) <= maxPrice);
    }

    if (startDate) {
      const filterDate = new Date(startDate);
      filtered = filtered.filter((e) => new Date(e.start_date) >= filterDate);
    }

    setFilteredEvents(filtered);
  }, [searchTitle, searchLocation, maxPrice, startDate, events]);

  

  // Event handlers
  const handleNewEventChange = (field: keyof Event, value: any) => {
    setNewEvent((prev) => ({ ...prev, [field]: value }));
  };

 const handleEditEventChange = (field: keyof Event, value: any) => {
  if (!editingEvent) return;

  const newValue =
    field === "price"
      ? value === "" || value === null ? undefined : Number(value)
      : value;

  setEditingEvent({ ...editingEvent, [field]: newValue });
};


  const showSnackbar = (
    message: string,
    severity: "success" | "error" | "info" | "warning"
  ) => {
    setSnackbarMessage(message);
    setSnackbarSeverity(severity);
    setSnackbarOpen(true);
  };

  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
  };

  

  // Event CRUD operations
  const handleCreateEvent = async () => {
    try {
      if (!newEvent.title || !newEvent.start_date || !newEvent.end_date) {
        showSnackbar("Будь ласка, заповніть обов'язкові поля", "error");
        return;
      }

      const formData = new FormData();
      Object.entries(newEvent).forEach(([key, value]) => {
        if (value !== undefined && value !== "") {
          formData.append(key, String(value));
        }
      });
      if (photoFile) {
  formData.append('photo', photoFile);  // Ключ 'photo' замість 'photoUrl'
}

      const res = await fetch("http://localhost:3000/api/events", {
        method: "POST",
        body: formData,
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => null);
        throw new Error(errorData?.message || "Помилка створення події");
      }

      const created = await res.json();
      setEvents((prev) => [...prev, created]);
      setFilteredEvents((prev) => [...prev, created]);

      setNewEvent({});
      setPhotoFile(null);
      setOpenAddDialog(false);
      showSnackbar("Подія успішно додана", "success");
    } catch (err) {
      showSnackbar(
        "Помилка: " + (err instanceof Error ? err.message : "невідома"),
        "error"
      );
    }
  };

// app/event/page.tsx або де у тебе логіка подій

async function handleUploadPhoto(file: File): Promise<string> {
  const formData = new FormData();
  formData.append('photo', file);

  const response = await fetch('http://localhost:3000/upload/photo', {
    method: 'POST',
    body: formData,
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`,
    },
  });

  if (!response.ok) {
    throw new Error('Failed to upload photo');
  }

  const data = await response.json();
  return data.url; // повертає URL картинки
}



  const handleUpdateEvent = async () => {
  if (!editingEvent?.id) return;

  try {
    const formData = new FormData();

    // виключаємо id і photoUrl з тіла
    for (const [key, value] of Object.entries(editingEvent)) {
      if (key === 'id' || key === 'photoUrl' || value === undefined || value === null) continue;

      // якщо поле price, переконайся, що це число >= 0
      if (key === 'price') {
        const priceNum = Number(value);
        if (isNaN(priceNum) || priceNum < 0) {
          throw new Error('Price must be a number >= 0');
        }
        formData.append(key, String(priceNum));
        continue;
      }

      formData.append(key, String(value));
    }

    // Якщо є файл фото, додаємо його
    if (editPhotoFile) {
      formData.append('photo', editPhotoFile);
    }

    const res = await fetch(`http://localhost:3000/api/events/${editingEvent.id}`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
      body: formData,
    });

    if (!res.ok) {
      const errorData = await res.json();
      throw new Error(`Failed to update event: ${res.status} - ${JSON.stringify(errorData)}`);
    }

    // Обробка успіху
  } catch (error) {
    console.error(error);
  }
};

  const handleDeleteEvent = async (id: string) => {
    try {
      const res = await fetch(`http://localhost:3000/api/events/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => null);
        throw new Error(errorData?.message || "Помилка видалення події");
      }

      setEvents((prev) => prev.filter((e) => e.id !== id));
      setFilteredEvents((prev) => prev.filter((e) => e.id !== id));
      setSelectedEvent(null);
      showSnackbar("Подія успішно видалена", "success");
    } catch (err) {
      showSnackbar(
        "Помилка: " + (err instanceof Error ? err.message : "невідома"),
        "error"
      );
    }
  };

  // Review operations
  const handleAddReview = async () => {
    if (!selectedEvent?.id || !newReview.text) return;

    try {
      const res = await fetch(
        `http://localhost:3000/api/events/${selectedEvent.id}/reviews`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
          body: JSON.stringify({
            text: newReview.text,
            rating: newReview.rating,
          }),
        }
      );

      if (!res.ok) {
        const errorData = await res.json().catch(() => null);
        throw new Error(errorData?.message || "Помилка додавання відгуку");
      }

      const updatedEvent = await res.json();
      setEvents((prev) =>
        prev.map((e) => (e.id === updatedEvent.id ? updatedEvent : e))
      );
      setFilteredEvents((prev) =>
        prev.map((e) => (e.id === updatedEvent.id ? updatedEvent : e))
      );
      setSelectedEvent(updatedEvent);
      setNewReview({ text: "", rating: 5 });
      showSnackbar("Відгук успішно додано", "success");
    } catch (err) {
      showSnackbar(
        "Помилка: " + (err instanceof Error ? err.message : "невідома"),
        "error"
      );
    }
  };

  // Payment validation
  const validatePaymentForm = () => {
    if (!firstName.trim()) {
      setPaymentError("Введіть ім'я");
      return false;
    }
    if (!lastName.trim()) {
      setPaymentError("Введіть прізвище");
      return false;
    }
    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) {
      setPaymentError("Введіть коректний email");
      return false;
    }
    const rawCard = cardNumber.replace(/\s/g, "");
    if (rawCard.length !== 16) {
      setPaymentError("Введіть 16 цифр картки");
      return false;
    }
    if (!/^\d{2}\/\d{2}$/.test(cardExpiry)) {
      setPaymentError("Введіть термін дії у форматі MM/YY");
      return false;
    }
    const [mm, yy] = cardExpiry.split("/").map(Number);
    if (mm < 1 || mm > 12) {
      setPaymentError("Некоректний місяць терміну дії");
      return false;
    }
    const currentYear = new Date().getFullYear() % 100;
    const currentMonth = new Date().getMonth() + 1;
    if (yy < currentYear || (yy === currentYear && mm < currentMonth)) {
      setPaymentError("Термін дії минув");
      return false;
    }
    if (!/^\d{3}$/.test(cardCVV)) {
      setPaymentError("Введіть CVV (3 цифри)");
      return false;
    }

    setPaymentError("");
    return true;
  };

  const handlePay = () => {
    if (!validatePaymentForm()) return;

    const rawCard = cardNumber.replace(/\s/g, "");

    // Test card numbers
    if (rawCard === "4242424242424242") {
      showSnackbar(
        `Оплата успішна! Ви купили білет на "${selectedEvent?.title}"`,
        "success"
      );
      setSelectedEvent(null);
      clearPaymentForm();
    } else if (rawCard === "4000000000000002") {
      setPaymentError("Оплата відхилена");
    } else {
      setPaymentError("Помилка оплати");
    }
  };

  const clearPaymentForm = () => {
    setFirstName("");
    setLastName("");
    setEmail("");
    setCardNumber("");
    setCardExpiry("");
    setCardCVV("");
    setPaymentError("");
  };

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      {/* Filter panel */}
      <Paper
        sx={{
          p: 3,
          mb: 3,
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          gap: 2,
        }}
      >
        <TextField
          label="Пошук по назві"
          value={searchTitle}
          onChange={(e) => setSearchTitle(e.target.value)}
          size="small"
          sx={{ flex: 1 }}
        />
        <FormControl size="small" sx={{ flex: 1 }}>
          <InputLabel>Локація</InputLabel>
          <Select
            value={searchLocation}
            label="Локація"
            onChange={(e) => setSearchLocation(e.target.value)}
          >
            <MenuItem value="">Всі</MenuItem>
            {cities.map((city) => (
              <MenuItem key={city} value={city}>
                {city}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <TextField
          label="Макс. ціна"
          type="number"
          inputProps={{ min: 0 }}
          value={maxPrice}
          onChange={(e) =>
            setMaxPrice(e.target.value === "" ? "" : Number(e.target.value))
          }
          size="small"
          sx={{ flex: 1 }}
        />
        <TextField
          label="Дата початку"
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          size="small"
          InputLabelProps={{ shrink: true }}
          sx={{ flex: 1 }}
        />
      </Paper>

      {/* Events grid */}
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            sm: "repeat(2, 1fr)",
            lg: "repeat(3, 1fr)",
            xl: "repeat(4, 1fr)",
          },
          gap: 3,
          mb: 4,
        }}
      >
        {filteredEvents.length === 0 ? (
          <Typography>Подій не знайдено</Typography>
        ) : (
          filteredEvents.map((event) => (
            <Paper
              key={event.id}
              sx={{
                p: 2,
                display: "flex",
                flexDirection: "column",
                gap: 1.5,
                borderRadius: 2,
                position: "relative",
                transition: "transform 0.2s",
                "&:hover": {
                  transform: "translateY(-4px)",
                  boxShadow: 3,
                },
              }}
              onClick={() => setSelectedEvent(event)}
            >
              {(user as any)?.id === event.createdBy && ( 

                <Box
                  sx={{
                    position: "absolute",
                    top: 8,
                    right: 8,
                    display: "flex",
                    gap: 1,
                  }}
                >
                  <IconButton
                    size="small"
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingEvent(event);
                      setOpenEditDialog(true);
                    }}
                    sx={{ backgroundColor: "rgba(255,255,255,0.8)" }}
                  >
                    <EditIcon fontSize="small" />
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteEvent(event.id);
                    }}
                    sx={{ backgroundColor: "rgba(255,255,255,0.8)" }}
                  >
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Box>
              )}
              <Box
                sx={{
                  height: 180,
                  borderRadius: 2,
                  backgroundColor: "#eee",
                  backgroundImage: event.photo 
  ? `url(http://localhost:3000/uploads/${event.photo})`  // Додано /uploads/
  : undefined,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                }}
              />
              <Typography variant="h6" noWrap>
                {event.title}
              </Typography>
              <Typography variant="body2" color="text.secondary" noWrap>
                {new Date(event.start_date).toLocaleDateString()} -{" "}
                {new Date(event.start_date).toLocaleTimeString()}
              </Typography>
              <Typography variant="body2" color="text.secondary" noWrap>
                {event.location} {event.street ? `, ${event.street}` : ""}
              </Typography>
              <Typography
                variant="body1"
                color="primary"
                fontWeight="bold"
                noWrap
              >
                Ціна: {event.price !== undefined ? `${event.price} ₴` : "Безкоштовно"}
              </Typography>
              <Button
                variant="contained"
                sx={{ mt: "auto" }}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedEvent(event);
                }}
              >
                Детальніше
              </Button>
            </Paper>
          ))
        )}
      </Box>

      {/* Add event button */}
<Box sx={{ display: "flex", gap: 2, mb: 3 }}>
  <Button variant="contained" onClick={() => setOpenAddDialog(true)}>
    Додати подію
  </Button>

  <Button variant="outlined" onClick={() => router.push("/statistics")}>
    Статистика
  </Button>
</Box>


      {/* Add event dialog */}
      <Dialog
        open={openAddDialog}
        onClose={() => setOpenAddDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>Нова подія</DialogTitle>
        <DialogContent sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <TextField
            label="Назва *"
            value={newEvent.title || ""}
            onChange={(e) => handleNewEventChange("title", e.target.value)}
            fullWidth
          />
          <TextField
            label="Опис"
            multiline
            rows={3}
            value={newEvent.description || ""}
            onChange={(e) => handleNewEventChange("description", e.target.value)}
            fullWidth
          />
          <TextField
            label="Початок *"
            type="datetime-local"
            value={newEvent.start_date || ""}
            onChange={(e) => handleNewEventChange("start_date", e.target.value)}
            InputLabelProps={{ shrink: true }}
            fullWidth
          />
          <TextField
            label="Кінець *"
            type="datetime-local"
            value={newEvent.end_date || ""}
            onChange={(e) => handleNewEventChange("end_date", e.target.value)}
            InputLabelProps={{ shrink: true }}
            fullWidth
          />
          <TextField
            label="Місто"
            value={newEvent.location || ""}
            onChange={(e) => handleNewEventChange("location", e.target.value)}
            fullWidth
          />
          <TextField
            label="Вулиця"
            value={newEvent.street || ""}
            onChange={(e) => handleNewEventChange("street", e.target.value)}
            fullWidth
          />
          <TextField
            label="Ціна"
            type="number"
            value={newEvent.price || ""}
            onChange={(e) => handleNewEventChange("price", e.target.value)}
            fullWidth
          />
          <Button variant="outlined" component="label">
  Завантажити фото
  <input
    hidden
    accept="image/*"
    type="file"
    onChange={(e) => {
      setPhotoFile(e.target.files?.[0] || null);
      handleNewEventChange('photo', e.target.files?.[0]?.name || '');
    }}
  />
</Button>
          {photoFile && <Typography variant="body2">{photoFile.name}</Typography>}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenAddDialog(false)}>Скасувати</Button>
          <Button onClick={handleCreateEvent} variant="contained">
            Створити
          </Button>
        </DialogActions>
      </Dialog>

      
      {/* Edit event dialog */}
      <Dialog
        open={openEditDialog}
        onClose={() => setOpenEditDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>Редагувати подію</DialogTitle>
        <DialogContent sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <TextField
            label="Назва *"
            value={editingEvent?.title || ""}
            onChange={(e) => handleEditEventChange("title", e.target.value)}
            fullWidth
          />
          <TextField
            label="Опис"
            multiline
            rows={3}
            value={editingEvent?.description || ""}
            onChange={(e) => handleEditEventChange("description", e.target.value)}
            fullWidth
          />
          <TextField
            label="Початок *"
            type="datetime-local"
            value={editingEvent?.start_date || ""}
            onChange={(e) => handleEditEventChange("start_date", e.target.value)}
            InputLabelProps={{ shrink: true }}
            fullWidth
          />
          <TextField
            label="Кінець *"
            type="datetime-local"
            value={editingEvent?.end_date || ""}
            onChange={(e) => handleEditEventChange("end_date", e.target.value)}
            InputLabelProps={{ shrink: true }}
            fullWidth
          />
          <TextField
            label="Місто"
            value={editingEvent?.location || ""}
            onChange={(e) => handleEditEventChange("location", e.target.value)}
            fullWidth
          />
          <TextField
            label="Вулиця"
            value={editingEvent?.street || ""}
            onChange={(e) => handleEditEventChange("street", e.target.value)}
            fullWidth
          />
          <TextField
            label="Ціна"
            type="number"
            value={editingEvent?.price || ""}
  onChange={(e) => handleEditEventChange("price", Number(e.target.value))}
            fullWidth
          />
          <Button variant="outlined" component="label">
            Змінити фото
            <input
              hidden
              accept="image/*"
              type="file"
              onChange={(e) => setEditPhotoFile(e.target.files?.[0] || null)}
            />
          </Button>
          {editPhotoFile ? (
            <Typography variant="body2">{editPhotoFile.name}</Typography>
          ) : (
            editingEvent?.photo && (
              <Typography variant="body2">
                Поточне фото: {editingEvent.photo.split("/").pop()}
              </Typography>
            )
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenEditDialog(false)}>Скасувати</Button>
          <Button onClick={handleUpdateEvent} variant="contained">
            Зберегти
          </Button>
        </DialogActions>
      </Dialog>

      {/* Event details dialog */}
<Dialog
  open={!!selectedEvent}
  onClose={() => setSelectedEvent(null)}
  maxWidth="md"
  fullWidth
  scroll="paper"
>
  <DialogTitle
    sx={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
    }}
  >
    <Typography variant="h4" component="div">
      {selectedEvent?.title}
    </Typography>
    <IconButton onClick={() => setSelectedEvent(null)}>
      <CloseIcon />
    </IconButton>
  </DialogTitle>

  <DialogContent dividers>
    {selectedEvent?.photo && (
      <Box
        sx={{
          width: "100%",
          height: 400,
          borderRadius: 2,
          mb: 3,
          backgroundImage: `url(http://localhost:3000/uploads/${selectedEvent.photo})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
    )}

    <Box sx={{ display: "flex", flexDirection: { xs: "column", md: "row" }, gap: 4 }}>
      <Box sx={{ flex: 1 }}>
        <Typography variant="h5" gutterBottom>Опис</Typography>
        <Typography paragraph sx={{ mb: 3 }}>
          {selectedEvent?.description || "Опис відсутній"}
        </Typography>

        <Typography variant="h5" gutterBottom>Деталі</Typography>
        <Stack spacing={2} sx={{ mb: 3 }}>
          <Box>
            <Typography variant="subtitle1">Дата та час:</Typography>
            <Typography>
              {new Date(selectedEvent?.start_date || "").toLocaleString()} –{" "}
              {new Date(selectedEvent?.end_date || "").toLocaleString()}
            </Typography>
          </Box>
          <Box>
            <Typography variant="subtitle1">Місце проведення:</Typography>
            <Typography>
              {selectedEvent?.location || "Не вказано"}
              {selectedEvent?.street ? `, ${selectedEvent.street}` : ""}
            </Typography>
          </Box>
          <Box>
            <Typography variant="subtitle1">Ціна:</Typography>
            <Typography color="error" fontWeight="bold">
              {selectedEvent?.price !== undefined ? `${selectedEvent.price} ₴` : "Безкоштовно"}
            </Typography>
          </Box>
        </Stack>
      </Box>

      {/* Квиток */}
      <Box sx={{ width: { xs: "100%", md: 350 }, flexShrink: 0 }}>
        <Typography variant="h5" gutterBottom>Купити квиток</Typography>
        <Stack spacing={2} sx={{ mb: 3 }}>
          <TextField
            label="Ім'я *"
            fullWidth
            value={firstName}
            onChange={(e) => {
              setFirstName(e.target.value);
              setPaymentError("");
            }}
            error={paymentError === "Введіть ім'я"}
            helperText={paymentError === "Введіть ім'я" ? paymentError : ""}
          />
          <TextField
            label="Прізвище *"
            fullWidth
            value={lastName}
            onChange={(e) => {
              setLastName(e.target.value);
              setPaymentError("");
            }}
            error={paymentError === "Введіть прізвище"}
            helperText={paymentError === "Введіть прізвище" ? paymentError : ""}
          />
          <TextField
            label="Email *"
            type="email"
            fullWidth
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              setPaymentError("");
            }}
            error={["Введіть email", "Введіть коректний email"].includes(paymentError)}
            helperText={["Введіть email", "Введіть коректний email"].includes(paymentError) ? paymentError : ""}
          />

          <TextField
            label="Номер картки *"
            fullWidth
            placeholder="0000 0000 0000 0000"
            value={cardNumber}
            onChange={(e) => {
              const value = e.target.value.replace(/\D/g, "").slice(0, 16);
              const formatted = value.replace(/(.{4})/g, "$1 ").trim();
              setCardNumber(formatted);
              setPaymentError("");
            }}
            error={[
              "Введіть 16 цифр картки",
              "Оплата відхилена",
              "Помилка оплати",
            ].includes(paymentError)}
            helperText={
              ["Введіть 16 цифр картки", "Оплата відхилена", "Помилка оплати"].includes(paymentError)
                ? paymentError
                : ""
            }
          />

          <Box sx={{ display: "flex", gap: 2 }}>
            <TextField
              label="Термін дії *"
              placeholder="MM/YY"
              fullWidth
              value={cardExpiry}
              onChange={(e) => {
                let val = e.target.value;
                if (/^[\d/]*$/.test(val)) {
                  if (val.length === 2 && !val.includes("/")) val = val + "/";
                  if (val.length > 5) val = val.slice(0, 5);
                  setCardExpiry(val);
                  setPaymentError("");
                }
              }}
              error={[
                "Введіть термін дії у форматі MM/YY",
                "Некоректний місяць терміну дії",
                "Термін дії минув",
              ].includes(paymentError)}
              helperText={
                ["Введіть термін дії у форматі MM/YY", "Некоректний місяць терміну дії", "Термін дії минув"].includes(paymentError)
                  ? paymentError
                  : ""
              }
            />

            <TextField
              label="CVV *"
              placeholder="123"
              fullWidth
              value={cardCVV}
              onChange={(e) => {
                const val = e.target.value.replace(/\D/g, "").slice(0, 3);
                setCardCVV(val);
                setPaymentError("");
              }}
              error={paymentError === "Введіть CVV (3 цифри)"}
              helperText={paymentError === "Введіть CVV (3 цифри)" ? paymentError : ""}
            />
          </Box>

          <Button
            variant="contained"
            size="large"
            onClick={handlePay}
            sx={{ mt: 2 }}
          >
            Оплатити
          </Button>
        </Stack>
      </Box>
    </Box>

    <Divider sx={{ my: 3 }} />

          {/* Reviews section */}
          <Typography variant="h5" gutterBottom>
            Відгуки
          </Typography>

          {selectedEvent?.reviews?.length ? (
            <Stack spacing={3} sx={{ mb: 3 }}>
              {selectedEvent.reviews.map((review) => (
                <Paper key={review.id} sx={{ p: 2 }}>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 1 }}>
                    <Avatar src={review.user.avatar} />
                    <Box>
                      <Typography fontWeight="bold">{review.user.name}</Typography>
                      <Typography variant="body2" color="text.secondary">
                        {new Date(review.createdAt).toLocaleString()}
                      </Typography>
                    </Box>
                    <Box sx={{ ml: "auto" }}>
                      <Rating value={review.rating} readOnly precision={0.5} />
                    </Box>
                  </Box>
                  <Typography>{review.text}</Typography>
                </Paper>
              ))}
            </Stack>
          ) : (
            <Typography color="text.secondary" sx={{ mb: 3 }}>
              Ще немає відгуків
            </Typography>
          )}

          {/* Add review form */}
          {user && (
            <Box>
              <Typography variant="h6" gutterBottom>
                Залишити відгук
              </Typography>
              <TextField
                multiline
                rows={3}
                fullWidth
                value={newReview.text}
                onChange={(e) =>
                  setNewReview({ ...newReview, text: e.target.value })
                }
                placeholder="Ваш відгук..."
                sx={{ mb: 2 }}
              />
              <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                <Rating
                  value={newReview.rating}
                  onChange={(_, value) =>
                    setNewReview({
                      ...newReview,
                      rating: value || 5,
                    })
                  }
                />
                <Button
                  variant="contained"
                  onClick={handleAddReview}
                  disabled={!newReview.text}
                >
                  Надіслати
                </Button>
              </Box>
            </Box>
          )}
        </DialogContent>
      </Dialog>

      

      {/* Snackbar */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={handleSnackbarClose}
          severity={snackbarSeverity}
          sx={{ width: "100%" }}
          variant="filled"
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Container>
  );
}