"use client";

import React, { useState, useEffect } from "react";
import {
  Typography,
  Button,
  Box,
  Paper,
  CircularProgress,
  Alert,
} from "@mui/material";
import { useRouter, useParams } from "next/navigation";
import Link from "next/link";

interface Event {
  id: number;
  title: string;
  description?: string;
  start_date: string;
  end_date: string;
  location?: string;
  street?: string;
  photoUrl?: string;
}

export default function EventDetailPage() {
  const params = useParams();
  const router = useRouter();

  const id = Array.isArray(params?.id) ? params.id[0] : params?.id;

  const [event, setEvent] = useState<Event | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!id) return;

    const fetchEvent = async () => {
      setLoading(true);
      setError("");
      try {
        const res = await fetch(`http://localhost:3000/api/events/${id}`);
        if (!res.ok) {
          // якщо статус не 200-299, викидаємо помилку
          throw new Error(`Подія з id=${id} не знайдена`);
        }
        const data = await res.json();
        setEvent(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Невідома помилка");
      } finally {
        setLoading(false);
      }
    };

    fetchEvent();
  }, [id]);

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
        <Button sx={{ mt: 2 }} variant="contained" onClick={() => router.back()}>
          Назад до списку
        </Button>
      </Box>
    );
  }

  if (!event) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="warning">Подія не знайдена</Alert>
        <Button sx={{ mt: 2 }} variant="contained" onClick={() => router.back()}>
          Назад до списку
        </Button>
      </Box>
    );
  }

  return (
    <Box sx={{ maxWidth: 800, mx: "auto", p: 3 }}>
      <Paper sx={{ p: 3, mb: 3 }} elevation={3}>
        <Box
          sx={{
            height: 300,
            borderRadius: 2,
            backgroundColor: "#eee",
            backgroundImage: event.photoUrl ? `url(${event.photoUrl})` : undefined,
            backgroundSize: "cover",
            backgroundPosition: "center",
            mb: 3,
          }}
        />

        <Typography variant="h4" gutterBottom>
          {event.title}
        </Typography>

        <Typography variant="body1" paragraph>
          {event.description || "Опис відсутній"}
        </Typography>

        <Typography variant="subtitle1" gutterBottom>
          <strong>Дата:</strong>{" "}
          {new Date(event.start_date).toLocaleString()} —{" "}
          {new Date(event.end_date).toLocaleString()}
        </Typography>

        <Typography variant="subtitle1" gutterBottom>
          <strong>Місце:</strong> {event.location || "Не вказано"}
          {event.street ? `, ${event.street}` : ""}
        </Typography>
      </Paper>

      <Box sx={{ display: "flex", gap: 2 }}>
        <Link href={`/events/${event.id}/tickets`} passHref>
          <Button variant="contained" size="large">
            Купити білет
          </Button>
        </Link>

        <Button variant="outlined" size="large" onClick={() => router.back()}>
          Назад до списку
        </Button>
      </Box>
    </Box>
  );
}
