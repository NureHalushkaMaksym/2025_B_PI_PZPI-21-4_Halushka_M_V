export interface ApiReview {
  id: number;
  user_id: number;
  rating: number;
  comment: string;
  created_at: string;
}

export interface Review {
  id: number;
  userId: number;
  rating: number;
  text: string;
  createdAt: string;
}
