"use client";

import React, { useEffect, useState } from "react";
import {
  Container,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Typography,
  Box,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
} from "@mui/material";

type Ticket = {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  price: number;
  confirmed: boolean;
};

type Event = {
  id: string;
  title: string;
  tickets?: Ticket[];
};

type Stats = {
  totalTickets: number;
  totalSum: number;
  averagePrice: number;
  confirmedPercent: number;
};

export default function StatisticsPage() {
  const [events, setEvents] = useState<Event[]>([]);
  const [selectedEventId, setSelectedEventId] = useState("");
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const res = await fetch("http://localhost:3000/api/events");
        if (!res.ok) throw new Error("Failed to fetch events");
        const data = await res.json();
        setEvents(data);
      } catch (error) {
        console.error("Помилка завантаження подій:", error);
      }
    };
    fetchEvents();
  }, []);

  const handleGenerateStats = () => {
    const event = events.find((e) => e.id === selectedEventId);
    if (!event) return;

    const tickets = event.tickets ?? [];
    const confirmedTickets = tickets.filter((t) => t.confirmed);
    const totalTickets = confirmedTickets.length;
    const totalSum = confirmedTickets.reduce((sum, ticket) => sum + (ticket.price ?? 0), 0);
    const averagePrice = totalTickets > 0 ? totalSum / totalTickets : 0;
    const totalAllTickets = tickets.length;
    const confirmedPercent = totalAllTickets > 0 ? (totalTickets / totalAllTickets) * 100 : 0;

    setStats({ totalTickets, totalSum, averagePrice, confirmedPercent });
  };

  const handleConfirm = async (ticketId: string) => {
    try {
      const res = await fetch(`http://localhost:3000/api/tickets/${ticketId}/confirm`, {
        method: "PATCH",
      });

      if (!res.ok) throw new Error("Не вдалося підтвердити квиток");

      // Оновлюємо локальний стан
      setEvents((prevEvents) =>
        prevEvents.map((event) =>
          event.id === selectedEventId
            ? {
                ...event,
                tickets: event.tickets?.map((t) =>
                  t.id === ticketId ? { ...t, confirmed: true } : t
                ),
              }
            : event
        )
      );
    } catch (error) {
      console.error("Помилка підтвердження:", error);
    }
  };

  const selectedEvent = events.find((e) => e.id === selectedEventId);

  return (
    <Container maxWidth="sm" sx={{ mt: 4 }}>
      <Typography variant="h5" gutterBottom>
        Статистика подій
      </Typography>

      <FormControl fullWidth sx={{ mb: 2 }}>
        <InputLabel id="event-select-label">Оберіть подію</InputLabel>
        <Select
          labelId="event-select-label"
          value={selectedEventId}
          label="Оберіть подію"
          onChange={(e) => {
            setSelectedEventId(e.target.value);
            setStats(null);
          }}
        >
          {events.map((event) => (
            <MenuItem key={event.id} value={event.id}>
              {event.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      {selectedEvent && selectedEvent.tickets && (
        <>
          <Typography variant="h6" gutterBottom>
            Квитки
          </Typography>
          <List dense>
            {selectedEvent.tickets.map((ticket) => (
              <ListItem key={ticket.id} divider>
                <ListItemText
                  primary={`${ticket.firstName} ${ticket.lastName} — ${ticket.email}`}
                  secondary={ticket.confirmed ? "✅ Підтверджено" : "❌ Не підтверджено"}
                />
                {!ticket.confirmed && (
                  <ListItemSecondaryAction>
                    <Button
                      variant="outlined"
                      size="small"
                      onClick={() => handleConfirm(ticket.id)}
                    >
                      Підтвердити
                    </Button>
                  </ListItemSecondaryAction>
                )}
              </ListItem>
            ))}
          </List>
        </>
      )}

      <Button
        variant="contained"
        disabled={!selectedEventId}
        onClick={handleGenerateStats}
        sx={{ mt: 2 }}
      >
        Сформувати статистику
      </Button>

      {stats && (
        <Box sx={{ mt: 3 }}>
          <Typography>
            Кількість підтверджених квитків: <strong>{stats.totalTickets}</strong>
          </Typography>
          <Typography>
            Загальна сума: <strong>{stats.totalSum.toFixed(2)} ₴</strong>
          </Typography>
          <Typography>
            Середня ціна квитка: <strong>{stats.averagePrice.toFixed(2)} ₴</strong>
          </Typography>
          <Typography>
            Відсоток підтверджених квитків: <strong>{stats.confirmedPercent.toFixed(1)}%</strong>
          </Typography>
        </Box>
      )}
    </Container>
  );
}
