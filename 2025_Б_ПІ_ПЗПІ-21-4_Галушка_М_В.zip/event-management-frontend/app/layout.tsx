'use client';

import React, { ReactNode } from 'react';
import { SnackbarProvider } from 'notistack';
import { AuthProvider } from './contexts/AuthContext';
import Header from './components/Header';

interface RootLayoutProps {
  children: ReactNode;
}

export default function RootLayout({ children }: RootLayoutProps) {
  return (
    <html lang="en">
      <body>
        <SnackbarProvider anchorOrigin={{ vertical: 'top', horizontal: 'right' }}>
          <AuthProvider>
            <Header />
            <main>{children}</main>
          </AuthProvider>
        </SnackbarProvider>
      </body>
    </html>
  );
}
